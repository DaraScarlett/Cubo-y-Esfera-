﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CubeChangesPlayerLife
{
	public class GameMaster : MonoBehaviour {

         public Player Sphere;

        // Use this for initialization

        void Start () {



		}
        public void OnMouseDown()
        {
            Sphere.life--;
        }
        // Update is called once per frame
        void Update () {
            

		}
	}
}
